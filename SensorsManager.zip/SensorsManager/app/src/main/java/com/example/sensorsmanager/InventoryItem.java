package com.example.sensorsmanager;

// InventoryItem.java
public class InventoryItem {
    private int id;
    private String name;
    private int quantity;

    // Constructor, getters, setters, etc.
}
