package com.example.sensorsmanager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.MessageFormat;
import DatabaseContract.UserEntry;

public class LoginActivity extends MainActivity {
    private EditText usernameEditText, passwordEditText;
    private DatabaseHelper databaseHelper;
    private Object DatabaseContract;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.editTextUsername);
        passwordEditText = findViewById(R.id.editTextPassword);
        databaseHelper = new DatabaseHelper(this);

        Button loginButton = findViewById(R.id.buttonLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (isValidCredentials(username, password)) {
                    // User login successful, navigate to the main activity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button createAccountButton = findViewById(R.id.buttonCreateAccount);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (createAccount(username, password)) {
                    Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void startActivity(Intent intent) {
    }

    private boolean isValidCredentials(String username, String password) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] projection = {UserEntry.COLUMN_USERNAME};
        String selection = MessageFormat.format("{0} = ? AND {1} = ?",
                DatabaseContract.UserEntry.COLUMN_USERNAME,
                DatabaseContract.UserEntry.COLUMN_PASSWORD);
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(
                DatabaseContract.UserEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return isValid;
    }

    private boolean createAccount(String username, String password) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.UserEntry.COLUMN_USERNAME,
                username);
        values.put(DatabaseContract.UserEntry.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DatabaseContract.UserEntry.TABLE_NAME, null, values);
        db.close();
        return newRowId != -1;
    }

    private class UserEntry {
        public static final String COLUMN_USERNAME = ;
    }
}


