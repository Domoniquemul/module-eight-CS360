package DatabaseContract;

public class UserEntry {
}
